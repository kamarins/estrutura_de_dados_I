#include "corretor.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct submissao{
  char id;
  int tempo;
  char julg[20];
};

struct pontuacao{
  int s;
  int p;
};

//ler a quantidade de submissoes do caso teste
void lerQuantidade(int *qtd){
    scanf("%d", qtd);
}

//aloca memoria para armazenar as submissoes e para a pontucao
TADsub* alocaSubmissoes(TADsub *S, int qtd){
  S = (TADsub*) malloc (qtd * sizeof(TADsub));

  if (S == NULL){      
    exit(1);
  }

  return S;
}

TADpont* alocaPontuacao(TADpont *P){
  P = (TADpont*) malloc (sizeof(TADpont));

  if (P == NULL){      
    exit(1);
  }

  P->p = 0;
  P->s = 0; 

  return P;
}

//desaloca memoria para armazenada para as submissoes e para a pontuacao
TADpont* liberaPontuacao(TADpont *P){
  free(P);

  return P;
}

TADsub* liberaSubmissoes(TADsub *S){
  free(S);

  return S;
}

void lerSubmissoes(TADsub *S, int qtd){
  int i;
  for (i = 0; i < qtd; i++){
      scanf(" %c ", &S[i].id);
      scanf(" %d ", &S[i].tempo);
      scanf(" %s ", S[i].julg); 
  }
}

void calculaPontuacao(TADsub *S, int qtd, TADpont *P){
  
  for (int i = 0; i < qtd ; i++){
    
    if (strcmp(S[i].julg,"correto") == 0){ 
      P->p += S[i].tempo;
      P->s ++;
      quantidadeIncompletos(S,P,qtd,i);

    }
  }
}

void quantidadeIncompletos(TADsub *S, TADpont *P, int qtd, int i){

  for (int k=0; k<qtd; k++){
    if ((S[i].id == S[k].id) &&  strcmp(S[k].julg,"incompleto") == 0) {
      P->p += 20;
    } 
  }  
}

void printPontuacao(TADpont *P){
  printf("%d %d\n", P->s, P->p);
}
