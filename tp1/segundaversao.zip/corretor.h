# ifndef corretor_h
# define corretor_h

//estrutura submissao 
typedef struct submissao TADsub;
typedef struct pontuacao TADpont;

//ler a quantidade de submissoes do caso teste
void lerQuantidade(int *qtd);

//aloca memoria para armazenar as submissoes
TADsub* alocaSubmissoes(TADsub *S, int qtd);
TADpont* alocaPontuacao(TADpont *P);

//desaloca memoria para armazenada para as submissoes e a pontuacao
TADsub* liberaSubmissoes(TADsub*S);
TADpont* liberaPontuacao(TADpont *P);

//ler as submissoes do aluno
void lerSubmissoes(TADsub *S, int qtd);

//calcula pontuacao
void calculaPontuacao(TADsub *S, int qtd, TADpont *P);
void quantidadeIncompletos(TADsub *S, TADpont *P, int qtd, int i );

//Print o resultado do aluno 
void printPontuacao(TADpont *P);

# endif
