Arquivo zip gerado em: 13/06/2021 22:15:20 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Aula Prática 3 - Alocação dinâmica de tipos abstratos de dados