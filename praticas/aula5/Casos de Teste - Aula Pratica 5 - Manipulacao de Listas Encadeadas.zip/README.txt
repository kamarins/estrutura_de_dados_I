Arquivo zip gerado em: 05/07/2021 13:16:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Aula Prática 5 - Manipulação de Listas Encadeadas