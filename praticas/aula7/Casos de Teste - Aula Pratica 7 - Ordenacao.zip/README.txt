Arquivo zip gerado em: 18/07/2021 20:25:34 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Aula Prática 7 - Ordenação